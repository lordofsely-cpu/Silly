package com.sely.assistant

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject

class SelyWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (widgetId in appWidgetIds) {
            val prefs = context.getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)
            val raw = prefs.getString("sely_reminder_list", "[]") ?: "[]"
            val arr = JSONArray(raw)
            val nextReminder = if (arr.length() > 0) {
                val obj = arr.getJSONObject(0)
                "${obj.getString("task")} at ${obj.getString("display")}"
            } else "No reminders set"

            val views = RemoteViews(context.packageName, R.layout.widget_sely)
            views.setTextViewText(R.id.widget_reminder_text, nextReminder)

            val openAppIntent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}
